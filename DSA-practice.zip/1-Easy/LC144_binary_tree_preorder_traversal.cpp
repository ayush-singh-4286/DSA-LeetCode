// LeetCode Question: 144 - Binary Tree Preorder Traversal
// Topics: Binary Tree, Recursion, Tree Traversal, DFS, Preorder

class Solution {
    void preorder(TreeNode* root, vector<int>& ans) {
        if(root == NULL)
            return;
        ans.push_back(root->val);
        preorder(root->left, ans);
        preorder(root->right, ans);
    }
public:
    vector<int> preorderTraversal(TreeNode* root) {
        vector<int> ans;
        preorder(root, ans);
        return ans;
    }
};
