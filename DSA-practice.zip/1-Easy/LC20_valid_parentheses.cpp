// LeetCode Question 20: Valid Parentheses
// Topics: Stack, String, Bracket Matching

#include <stack>
#include <string>
using namespace std;

class Solution {
public:
    bool isValid(string str) {
        stack<char> s;
        for(int i = 0; i < str.length(); i++){
            char ch = str[i];

            if(ch == '(' || ch == '{' || ch == '['){
                s.push(ch);
            } else {
                if(s.empty()){
                    return false;
                } else {
                    char top = s.top();
                    if((ch == ')' && top == '(') || 
                       (ch == ']' && top == '[') || 
                       (ch == '}' && top == '{')){
                        s.pop();
                    } else {
                        return false;
                    }
                }
            }
        }
        return s.empty();
    }
};
